const express = require('express');
const bcrypt = require('bcryptjs');
const prisma = require('../prismaClient');
const userSchema = require('../schemas/userSchema');

const router = express.Router();

router.post('/users', async (req, res) => {
  try {
    const parsedData = userSchema.parse(req.body);
    const hashedPassword = await bcrypt.hash(parsedData.password, 10);
    parsedData.password = hashedPassword;

    const user = await prisma.user.create({
      data: parsedData,
    });
    res.json(user);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Erro ao validar dados, verifique seus dados!", errors: error.errors });
    }
    res.status(500).json({ message: "Impossível cadastrar usuário, ou o email inserido já está cadastrado no sistema" });
  }
});

router.get('/users', async (req, res) => {
  const users = await prisma.user.findMany();
  res.json(users);
});

router.get('/users/:id', async (req, res) => {
  const { id } = req.params;
  const user = await prisma.user.findUnique({
    where: { id: parseInt(id) }
  });

  if (!user) return res.status(404).json({ message: "Usuário não encontrado" });
  res.json(user);
});

module.exports = router;