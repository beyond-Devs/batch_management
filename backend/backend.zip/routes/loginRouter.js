const express = require('express');
const bcrypt = require('bcryptjs');
const prisma = require('../prismaClient');
const loginSchema = require('../schemas/loginSchema');

const router = express.Router();

router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email e senha são obrigatórios.' });
  }

  const user = await prisma.user.findUnique({ where: { email } });

  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).json({ message: 'Email ou senha incorrectos' });
  }

  res.json({ user });
});

module.exports = router;